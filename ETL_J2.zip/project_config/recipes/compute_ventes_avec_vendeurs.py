import dataiku
import pandas as pd

ventes = dataiku.Dataset("ventes").get_dataframe()
vendeurs = dataiku.Dataset("vendeurs").get_dataframe()

# LEFT JOIN
df = ventes.merge(
    vendeurs[["ID Vendeur", "Nom", "Objectif"]],
    on="ID Vendeur", how="left"
)

# GROUP BY
res = (
    df.groupby(["ID Vendeur", "Nom", "Mois", "Trimestre", "Objectif"], as_index=False)
      .agg(
          nb_ventes=("Montant", "size"),
          ca_total=("Montant", "sum"),
          cout_total=("Coût Total", "sum"),
      )
)

# Colonnes calculées
res["marge_totale"] = res["ca_total"] - res["cout_total"]
res["taux_marge"] = (res["marge_totale"] / res["ca_total"] * 100).round(1)
res["atteinte_objectif_pct"] = (res["ca_total"] / res["Objectif"] * 100).round(1)

# ORDER BY
res = res.sort_values(["Mois", "ca_total"], ascending=[True, False])

dataiku.Dataset("ventes_avec_vendeurs").write_with_schema(res)