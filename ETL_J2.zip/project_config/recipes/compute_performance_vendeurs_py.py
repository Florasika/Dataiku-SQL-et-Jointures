import dataiku
import numpy as np
import pandas as pd

# --- Noms de colonnes : à adapter à ton schéma réel ---
ID_V   = "ID Vendeur"
ID_VTE = "ID Vente"
MONTANT = "Montant"
COUT   = "Coût Total"
QTE    = "Quantité"
MOIS   = "Mois"
TRIM   = "Trimestre"
DATE   = "Date"

ventes = dataiku.Dataset("ventes").get_dataframe()
vendeurs = dataiku.Dataset("vendeurs").get_dataframe()
print(ventes.columns.tolist())  # vérifie dans les logs

ventes[DATE] = pd.to_datetime(ventes[DATE])

# --- Équivalent Group + Join ---
kpis = ventes.groupby(ID_V).agg(
    CA_Total=(MONTANT, "sum"),
    Cout_Total=(COUT, "sum"),
    Nb_Ventes=(ID_VTE, "count"),
    Qte_Totale=(QTE, "sum"),
    Panier_Moyen=(MONTANT, "mean"),
).reset_index()

perf = kpis.merge(
    vendeurs[[ID_V, "Nom", "Équipe", "Région", "Objectif"]],
    on=ID_V, how="left",
)
perf["Atteinte_Obj"] = perf["CA_Total"] / perf["Objectif"] * 100
perf["Statut"] = np.where(perf["Atteinte_Obj"] >= 100, "Atteint", "Non atteint")

# --- Équivalent de la requête SQL ---
v = ventes.merge(vendeurs[[ID_V, "Nom", "Objectif"]], on=ID_V, how="left")
sql_like = v.groupby([ID_V, "Nom", MOIS, TRIM, "Objectif"]).agg(
    nb_ventes=(ID_VTE, "count"),
    ca_total=(MONTANT, "sum"),
    cout_total=(COUT, "sum"),
).reset_index()
sql_like["marge_totale"] = sql_like["ca_total"] - sql_like["cout_total"]
sql_like["taux_marge"] = (sql_like["marge_totale"] / sql_like["ca_total"] * 100).round(1)
sql_like["atteinte_objectif_pct"] = (sql_like["ca_total"] / sql_like["Objectif"] * 100).round(1)

# --- Équivalent Window ---
w = ventes.sort_values([ID_V, DATE]).copy()
w["CA_Cumule"] = w.groupby(ID_V)[MONTANT].cumsum()
w["Rang_Mensuel"] = w.groupby(MOIS)[MONTANT].rank(method="dense", ascending=False)
w["Part_Mois_Pct"] = w[MONTANT] / w.groupby(MOIS)[MONTANT].transform("sum") * 100

# --- Écriture ---
dataiku.Dataset("performance_vendeurs_py").write_with_schema(perf)
dataiku.Dataset("ventes_avec_vendeur").write_with_schema(sql_like)
dataiku.Dataset("ventes_window2").write_with_schema(w)